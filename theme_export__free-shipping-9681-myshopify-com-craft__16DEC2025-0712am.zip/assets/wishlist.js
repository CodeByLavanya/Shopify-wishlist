document.addEventListener("DOMContentLoaded", function () {

  let wishlist = JSON.parse(localStorage.getItem("wishlist")) || [];
  document.querySelectorAll(".wish_list").forEach(button => {
  const ele = document.getElementById("pop-up-msg");
  
    const productId = button.dataset.productId;

    if (wishlist.some(item => item.id === productId)) {
      button.classList.add("active");
    }

    button.addEventListener("click", function () {
      if (button.classList.contains("active")) {
        ele.textContent = "Already Added to wishlist";
        button.classList.add("show-msg");
        setTimeout(() => {
        button.classList.remove("show-msg");
      }, 1000);
       return;
      };

      const product = {
        id: productId,
        title: button.dataset.productTitle,
        image: button.dataset.productImage,
        price: button.dataset.productPrice,
        url: button.dataset.productUrl
      };

      wishlist.push(product);
      localStorage.setItem("wishlist", JSON.stringify(wishlist));
      button.classList.add("active");
      button.classList.add("show-msg");
      setTimeout(() => {
        button.classList.remove("show-msg");
      }, 1000);
    });
  });
});
